import { StudyInterface } from "@/components/study-interface";

export default function StudyPage() {
  return <StudyInterface />;
}
