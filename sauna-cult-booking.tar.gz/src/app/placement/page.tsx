import { PlacementWizard } from "@/components/placement-wizard";

export default function PlacementPage() {
  return <PlacementWizard />;
}
